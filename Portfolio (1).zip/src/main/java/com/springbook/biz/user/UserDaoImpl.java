package com.springbook.biz.user;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.springbook.biz.BCrypt;

@Repository
public class UserDaoImpl implements UserDao {

	@Autowired
	private SqlSessionTemplate mybatis;
	
	@Override
	public void insert(UserVo vo) {		
		//암호화로 바꾼 비밀번호 입력
		vo.setPwd(BCrypt.hashpw(vo.getPwd(),BCrypt.gensalt()));
		
		mybatis.insert("User.user_Insert", vo);
	}

	@Override
	public List<UserVo> select(UserVo vo) {
		return mybatis.selectList("User.user_Select", vo);
	}

	@Override
	public void update(UserVo vo) {
		mybatis.update("User.user_Update", vo);
	}

	@Override
	public void delete(UserVo vo) {
		mybatis.delete("User.user_Delete", vo);
	}

	@Override
	public UserVo content(UserVo vo) {
		return mybatis.selectOne("User.user_Content", vo);
	}

	@Override
	public String loginCk(UserVo vo) {
		String str = "";
		
		//중복된 아이디 확인하기
		UserVo idCk = mybatis.selectOne("User.user_UserCk", vo);
		if(idCk == null) {
			str = "F"; //로그인 실패
			
		} else {
			//입력된 비밀번호 암호화로 변경해서 비교하기
			UserVo user = mybatis.selectOne("User.user_LoginCk", idCk);
			
			if(BCrypt.checkpw(vo.getPwd(), user.getPwd())) { //암호화된 비밀번호 확인
				str = vo.getId(); //로그인 성공
			} else {
				str = "F"; //로그인 실패
			}
			return str;
		}
		
		return str;
	}

	//아이디 중복값 찾아서 회원가입
	@Override
	public String userCk(UserVo vo) {
		UserVo user = mybatis.selectOne("User.user_UserCk", vo);
		
		String str = "";
		if(user == null) {
			str = "T"; //중복값 없음
		} else {
			str = "F"; //중복값 있음
		}
		
		return str;
	}

}
