package com.springbook.biz.user;

import lombok.Data;

@Data
public class UserVo {
	private String id;
	private String pwd;
	private String name;
	private String tel;
	private String email;
	private String postcode;
	private String address;
	private String detailAddress;
	private String extraAddress;
	
	private String ch1;
	private String ch2;
}

/*
create table users(
id varchar2(10) not null primary key,
pwd varchar2(100) not null,
name nvarchar2(10) not null,
tel varchar2(15) not null,
email varchar2(20) not null,
postcode char(5),
address nvarchar2(50),
detailAddress nvarchar2(30),
extraAddress nvarchar2(15)
);
 */