package com.springbook.biz.user;

import java.util.List;

public interface UserService {
	void insert(UserVo vo); //회원가입
	List<UserVo>select(UserVo vo); //회원목록
	void update(UserVo vo); //회원 정보 수정
	void delete(UserVo vo); //회원탈퇴
	
	UserVo content(UserVo vo); //회원 정보 확인
	
	String loginCk(UserVo vo); //로그인 확인
	String userCk(UserVo vo); //아이디 중복 확인
}
