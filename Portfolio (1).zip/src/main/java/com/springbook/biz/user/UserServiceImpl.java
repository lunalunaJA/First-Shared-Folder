package com.springbook.biz.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao dao;

	@Override
	public void insert(UserVo vo) {
		dao.insert(vo);
	}

	@Override
	public List<UserVo> select(UserVo vo) {
		return dao.select(vo);
	}

	@Override
	public void update(UserVo vo) {
		dao.update(vo);
	}

	@Override
	public void delete(UserVo vo) {
		dao.delete(vo);
	}

	@Override
	public UserVo content(UserVo vo) {
		return dao.content(vo);
	}

	@Override
	public String loginCk(UserVo vo) {
		return dao.loginCk(vo);
	}

	@Override
	public String userCk(UserVo vo) {
		return dao.userCk(vo);
	}
	
	
	
}
