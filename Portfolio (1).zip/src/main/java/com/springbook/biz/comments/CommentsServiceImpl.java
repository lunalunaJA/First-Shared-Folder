package com.springbook.biz.comments;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CommentsServiceImpl implements CommentsService{

	@Autowired
	private CommentsDao dao;
	
	@Override
	public void insert(CommentsVo vo) {
		dao.insert(vo);
	}

	@Override
	public CommentsVo content(CommentsVo vo) {
		return dao.content(vo);
	}

	@Override
	public void delete(CommentsVo vo) {
		dao.delete(vo);
	}

	@Override
	public void update(CommentsVo vo) {
		dao.update(vo);
	}

}
