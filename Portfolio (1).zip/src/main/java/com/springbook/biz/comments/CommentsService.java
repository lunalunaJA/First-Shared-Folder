package com.springbook.biz.comments;

public interface CommentsService {
	void insert(CommentsVo vo);
	CommentsVo content(CommentsVo vo);
	void delete(CommentsVo vo);
	void update(CommentsVo vo);
}
