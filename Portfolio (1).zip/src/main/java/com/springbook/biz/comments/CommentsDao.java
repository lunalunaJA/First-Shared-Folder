package com.springbook.biz.comments;

import java.util.List;

public interface CommentsDao {
	void insert(CommentsVo vo);
	CommentsVo content(CommentsVo vo);
	void delete(CommentsVo vo);
	void update(CommentsVo vo);
}
