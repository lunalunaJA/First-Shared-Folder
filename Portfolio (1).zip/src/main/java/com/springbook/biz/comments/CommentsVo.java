package com.springbook.biz.comments;

import lombok.Data;

@Data
public class CommentsVo {
	private int num; //댓글번호
	private int idx; //게시글 번호 받아오기
	private String id; //작성자
	private int seq; //부모-자식 구분
	private String detail; //댓글 내용
}
/*
create table comments(
num number(5) not null primary key,
idx number(5) not null,
id varchar2(10) not null,
seq number(5),
detail nvarchar2(100) not null
);

create sequence comments_num
increment by 1
start with 1;
*/