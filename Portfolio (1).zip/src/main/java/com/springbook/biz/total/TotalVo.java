package com.springbook.biz.total;

import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class TotalVo {
	
	//users
	private String id;
	private String pwd;
	private String name;
	private String tel;
	private String email;
	private String postcode;
	private String address;
	private String detailAddress;
	private String extraAddress;
	
	private String ch1;
	private String ch2;
	
	
	//board
	private int idx;
	//private String id; //작성자
	private Date rdate; //작성일
	private Date udate; //수정일
	private String sname; //가게이름
	private String phone; //가게번호
	private String mmenu; //메인상품
	private String open; //오픈시간
	private String off; //휴일
	private String instar; //인스타 주소
	//private String postcode;
	//private String address;
	//private String detailAddress;
	//private String extraAddress;
	
	private MultipartFile imgUploadFile; //실제 이미지 파일
	private String img; // 테이블 이미지 이름
	
	//private String ch1;
	//private String ch2;
	
	
	//comments
	private int num; //댓글번호
	//private int idx; //게시글 번호 받아오기
	//private String id; //작성자
	private int seq; //부모-자식 구분
	private String detail; //댓글 내용
		
}
