package com.springbook.biz.board;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDaoImpl implements BoardDao {

	@Autowired
	private SqlSessionTemplate mybatis;
	
	@Override
	public void insert(BoardVo vo) {
		mybatis.insert("Board.board_Insert", vo);
	}

	@Override
	public List<BoardVo> select(BoardVo vo) {
		return mybatis.selectList("Board.board_Select");
	}

	@Override
	public void delete(BoardVo vo) {
		mybatis.delete("Board.board_Delete", vo);
	}

	@Override
	public BoardVo content(BoardVo vo) {
		return mybatis.selectOne("Board.board_Content", vo);
	}

	//NO 이미지 업데이트
	@Override
	public void update(BoardVo vo) {
		mybatis.update("Board.board_Update", vo);
	}
	
	//이미지 업데이트
	@Override
	public void updateFile(BoardVo vo) {
		mybatis.update("Board.board_UpdateFile", vo);
	}

}
