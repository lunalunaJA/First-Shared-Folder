package com.springbook.biz.board;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardDao dao;

	@Override
	public void insert(BoardVo vo) {
		dao.insert(vo);
	}

	@Override
	public List<BoardVo> select(BoardVo vo) {
		return dao.select(vo);
	}

	@Override
	public void delete(BoardVo vo) {
		dao.delete(vo);
	}

	@Override
	public BoardVo content(BoardVo vo) {
		return dao.content(vo);
	}

	
	@Override
	public void update(BoardVo vo) {
		dao.update(vo);
	}
	
	@Override
	public void updateFile(BoardVo vo) {
		dao.updateFile(vo);
	}
	
	
}
