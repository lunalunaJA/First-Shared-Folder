package com.springbook.biz.board;

import java.util.List;

public interface BoardDao {
	void insert(BoardVo vo); //게시글 작성
	List<BoardVo>select(BoardVo vo); //게시판 목록보기
	void delete(BoardVo vo); //게시글 삭제
	
	BoardVo content(BoardVo vo); //게시글 수정
	
	void update(BoardVo vo); //이미지 수정X
	void updateFile(BoardVo vo); //이미지 수정O
}
