package com.springbook.presentation;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.springbook.biz.user.UserService;
import com.springbook.biz.user.UserVo;

@Controller
public class UserController {
	@Autowired
	private UserService service;
	
	@ModelAttribute("conditionMap")
	public Map<String, String> searchconditionMap(){
		Map<String, String>	conditionMap = new HashMap<String, String>();
		conditionMap.put("아이디", "id");
		conditionMap.put("이름", "name");
		return conditionMap;		
	}
	
	//회원목록으로 가기
	@RequestMapping("user_list.do")
	public String list(UserVo vo, Model model) {
		model.addAttribute("li", service.select(vo));
				
		return "/user/list.jsp";
	}
	
	
	
	//회원가입 화면으로 이동
	@RequestMapping("user_join.do")
	public String join() {
		return "/user/join.jsp";
	}
	
	//아이디 중복 확인
	@RequestMapping("user_userCk.do")
	public void userCk(UserVo vo, HttpServletResponse response) throws Exception {
		PrintWriter out = response.getWriter(); //출력
		
		String user = service.userCk(vo); //동일한 아이디 있는지 확인
		if(user.equals("F")) { //중복 아이디가 O
			out.println(1);  // out을 사용하여 값을 리턴함
			
		} else if(user.equals("T")){ //중복 아이디가 X
			out.println(0);
		}
	}
	
	//회원가입 성공하면 가기
	@RequestMapping("user_joinOk.do")
	public String joinOk(UserVo vo, HttpServletResponse response, HttpSession session) {
		service.insert(vo);
		return "index.jsp";
		
	}
	
	
	
	//로그인 화면으로 이동
	@RequestMapping(value="/user_login.do", method=RequestMethod.GET)
	public String login() {			  
		return "/user/login.jsp";
	}
	
	//로그인 하기
	@RequestMapping("user_loginOk.do")
	public void loginOk(UserVo vo, HttpServletResponse response, HttpSession session, HttpServletRequest request) throws Exception {
		PrintWriter out = response.getWriter(); //출력
		
		//세선받기
		session = request.getSession();
		
		//Dao에서 아이디랑 비밀번호 맞는지 체크
		String user = service.loginCk(vo);
		
		if(user.equals("F")) { //아이디랑 비밀번호가 틀리면
			out.println(1);
			
		} else { //아이디랑 비밀번호가 맞으면
			session.setAttribute("session", user);
			out.println(0);
		}
		 
	}

   //로그아웃하고 세션 삭제
   @RequestMapping("user_logout.do")
   public String logout(HttpSession sesion) {
	   //세션 종료
	   sesion.invalidate();  
	   
	   return "index.jsp";
	   
   }
   
   //회원정보 확인
   @RequestMapping("user_content.do")
   public String content(UserVo vo, Model model) {
	   model.addAttribute("content", service.content(vo));
	   
	   return "/user/content.jsp";
   }
   
   //회원정보 수정
   @RequestMapping("user_update.do")
   public String userUpdate(UserVo vo) {
	   service.update(vo);
	   
	return "index.jsp";
	   
   }
   
   //회원탈퇴
   @RequestMapping("user_delete.do")
   public String delete(UserVo vo, HttpSession sesion) {
	   
	   service.delete(vo);
	   sesion.invalidate();
	   
	   return "index.jsp";
   }
}
