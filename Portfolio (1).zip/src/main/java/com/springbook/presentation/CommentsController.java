package com.springbook.presentation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springbook.biz.comments.CommentsServiceImpl;
import com.springbook.biz.comments.CommentsVo;

@Controller
public class CommentsController {

	@Autowired
	private CommentsServiceImpl service; 
	
	@RequestMapping("comments_insert.do")
	public void insert(CommentsVo vo) {		
		service.insert(vo);		
	}
}
