package com.springbook.presentation;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import com.springbook.biz.board.BoardService;
import com.springbook.biz.board.BoardVo;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService service;
	
	//게시물 목록보기
	@RequestMapping("board_list.do")
	public String select(BoardVo vo, Model model) {
		model.addAttribute("li", service.select(vo));
		
		return "/board/list.jsp";		
	}
	
	//게시물 작성하는 페이지로 이동
	@RequestMapping("board_write.do")
	public String writer() {		
		return "/board/writer.jsp";		
	}
	
	//게시물 작성하기
	@RequestMapping("board_writeOk.do") //값 저장하고 목록.jsp로 이동
	public String insert(BoardVo vo, HttpServletRequest request) throws Exception {
		//path 설정
		String path = request.getSession().getServletContext().getRealPath("/board/files/");
		System.out.println(path);
		//이미지 가져오기
		MultipartFile imgUpdateFile = vo.getImgUploadFile();
		String fileNmae = imgUpdateFile.getOriginalFilename();
		File f = new File(path+fileNmae);
		
		//이미지 파일명 자르기
		String onlyFilename = "";
		String extension = "";
		
		//현재 시간 가져오기
		long time = System.currentTimeMillis();
		SimpleDateFormat dayTime = new SimpleDateFormat("HHmmss"); //시분초
		String timeStr = dayTime.format(time);

		Date now = new Date();
		
		if(!imgUpdateFile.isEmpty()) {
			if(f.exists()) {
				// 중복 파일이 존재하면
				onlyFilename = fileNmae.substring(0, fileNmae.indexOf(".")); //처음부터 .바로 앞까지
				extension = fileNmae.substring(fileNmae.indexOf(".")); //.부터 끝까지
				fileNmae = onlyFilename + "_" + timeStr + extension ; //파일이름_시분초.확장자
			  
				imgUpdateFile.transferTo(new File(path+fileNmae));
			} else {
				// 중복 파일이 존재하지 않으면   
				imgUpdateFile.transferTo(new File(path+fileNmae));
			}
		}
		//입력 전 새로운 값 받아주기
		vo.setImg(fileNmae);
		vo.setRdate(now);
		
		System.out.println(vo.toString());
		
		service.insert(vo);
		
		return "board_list.do";		
	}
	
	//게시물 자세히보기
	@RequestMapping("board_content.do") 
	public String content(BoardVo vo, Model model) {
		model.addAttribute("m", service.content(vo));
		
		return "/board/content.jsp";
	}
	
	//게시물 수정하기
	@RequestMapping("board_update.do")
	public String update(BoardVo vo, Model model) {
		model.addAttribute("m", service.content(vo));
		
		return "/board/update.jsp";
	}
	
	//값 받아서 수정 후 목록.do로 이동
	@RequestMapping("board_updateOk.do") 
	public String updateOk(BoardVo vo, HttpServletRequest request) throws Exception {
		//path 설정
		String	path=request.getSession().getServletContext().getRealPath("/board/files/");
				
		//이미지 가져오기
		MultipartFile imgUpdateFile = vo.getImgUploadFile();
		String fileNmae = imgUpdateFile.getOriginalFilename();
		File  f = new File(path+fileNmae);

		//현재 시간 가져오기
		long time = System.currentTimeMillis();
		SimpleDateFormat dayTime = new SimpleDateFormat("HHmmss"); //시분초
		String timeStr = dayTime.format(time);
		
		Date now = new Date();
				
		if(!imgUpdateFile.isEmpty()) {//이미지가 있으면
			//기존 파일 삭제
			BoardVo img = service.content(vo); //가져올 이미지 파일 설정
			File fDel = new File(path+img.getImg()); //파일 경로 찾기
			
			if(fDel.exists()) { //5. 파일이 존재하면 삭제
				fDel.delete();
			}
			
			if(f.exists()) {
				// 중복 파일이 존재하면
				String onlyFilename = fileNmae.substring(0, fileNmae.indexOf(".")); //처음부터 .바로 앞까지
				String extension = fileNmae.substring(fileNmae.indexOf(".")); //.부터 끝까지
				fileNmae = onlyFilename + "_" + timeStr + extension ; //파일이름_시분초.확장자
			  
				imgUpdateFile.transferTo(new File(path+fileNmae));
				
			} else {
				// 중복 파일이 존재하지 않으면   
				imgUpdateFile.transferTo(new File(path+fileNmae));
				//System.out.println("fileNmae:" + fileNmae);
			}
			
			//입력 전 새로운 값 받아주기
			vo.setImg(fileNmae); //String
			vo.setUdate(now);
			
			service.updateFile(vo);
			System.out.println("이미지 OK 수정하기"+vo.toString());
			
		} else { //이미지가 없으면
			vo.setUdate(now);
			
			service.update(vo);
			System.out.println("이미지 None 수정하기"+vo.toString());
			
		}
				
		
		return "board_list.do";		
	}
	
	@RequestMapping("board_delete.do") //두개의 값 받아서 목록.do로 이동
	public String psdContent(BoardVo vo, HttpServletRequest request) {
		//파일삭제
		BoardVo img = service.content(vo); //1. 가져올 이미지 파일 설정
		img.getImg(); //2. 이미지 파일 가져오기
		String	path = request.getSession().getServletContext().getRealPath("/board/files/"); //3.패스 설정
		File f = new File(path+img.getImg()); //4. 파일 경로 찾기
		
		if(f.exists()) { //5. 파일이 존재하면 삭제
			f.delete();
		}
		
		//레코드삭제
		service.delete(vo);
		
		return "board_list.do";		
	}
}
